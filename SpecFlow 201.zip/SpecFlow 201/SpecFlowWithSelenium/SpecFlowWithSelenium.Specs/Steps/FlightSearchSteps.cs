﻿using NUnit.Framework;
using OpenQA.Selenium;
using SpecFlowWithSelenium.Pages;
using System;
using TechTalk.SpecFlow;

namespace SpecFlowWithSelenium.Specs.Steps
{
    [Binding]
    public class FlightSearchSteps : BasePage
    {
        private HomePage homePage;
        private const string SiteUrl = "https://www.airasia.com/en/home.page";
        public FlightSearchSteps(IWebDriver driver) : base(driver)
        {
            homePage = new HomePage(driver);
        }

        [Given(@"user has navigated to website")]
        [Scope(Tag = "flight", Feature = "Flight search")]
        public void GivenUserHasNavigatedToWebsite()
        {
            homePage.NavigateToURL(SiteUrl);
        }
        
        [Given(@"selects flight search option")]
        public void GivenSelectFlightSearchOption()
        {
            StringAssert.Contains("airasia",GetPageTitle().ToLower());
            //Website has changed, redirected to .in site
            //No flight icon, hence, searching flight on home page
        }


        [When(@"enter origin as (.*)")]
        public void WhenEnterOriginAs(string origin)
        {
            homePage.EnterSource(origin);
        }
        
        [When(@"enter destination as (.*)")]
        public void WhenEnterDestinationAs(string destination)
        {
            homePage.EnterDestination(destination);
        }

        [When(@"enter depart date as (.*)")]
        public void WhenEnterDepartDateAs(string departDate)
        {
            homePage.SelectDepartDate(departDate);
        }

        [When(@"select return date as (.*)")]
        public void WhenSelectReturnDateAs(string p0)
        {
            //Website has changed not valid on date select screen
            //Selecting depart date and proceeding to search flights
        }
        
        [When(@"click search button")]
        public void WhenSelectSearchResultsOptions()
        {
            homePage.SearchFlights();
        }
        
        [Then(@"search result page is displayed")]
        public void ThenSearchResultPageIsDisplayed()
        {
            //Verify search results page
            StringAssert.Contains("Affordable Flights To Your Destination", GetPageTitle());
        }
    }
}
