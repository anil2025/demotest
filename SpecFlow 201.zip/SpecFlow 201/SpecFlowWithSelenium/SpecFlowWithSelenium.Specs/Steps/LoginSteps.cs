﻿using NUnit.Framework;
using OpenQA.Selenium;
using SpecFlowWithSelenium.Pages;
using System;
using TechTalk.SpecFlow;

namespace SpecFlowWithSelenium.Specs.Steps
{
    [Binding]
    public class LoginSteps : BasePage
    {
        private HomePage homePage;
        private LoginPage loginPage;
        private const string SiteUrl = "https://www.airasia.com/en/home.page";
        public LoginSteps(IWebDriver driver) : base(driver)
        {
            homePage = new HomePage(driver);
            loginPage = new LoginPage(driver);
        }

        [Given(@"user has navigated to website")]
        [Scope(Tag = "login", Feature = "Login")]
        public void GivenUserHasNavigatedToWebsite()
        {
            homePage.NavigateToURL(SiteUrl);
        }

        [Given(@"clicks on login link")]
        public void GivenClickOnLoginLink()
        {
            homePage.LoginClick();
        }

        [When(@"username is entered as (.*)")]
        public void WhenUsernameIsEntered(string userName)
        {
            loginPage.EnterUserName(userName);
        }

        [When(@"password is entered as (.*)")]
        public void WhenPasswordIsEntered(string password)
        {
            loginPage.EnterPassword(password);
        }

        [When(@"clicks on sign in button")]
        public void WhenClickOnSignInButton()
        {
            loginPage.ClickSignIn();
        }
        
        [Then(@"error message should be displayed")]
        public void ThenErrorMessageShouldBeDisplayed()
        {
            string errorMessage = loginPage.GetErrorMessage();
            StringAssert.Contains("Either username / password is incorrect", errorMessage);
        }
    }
}
