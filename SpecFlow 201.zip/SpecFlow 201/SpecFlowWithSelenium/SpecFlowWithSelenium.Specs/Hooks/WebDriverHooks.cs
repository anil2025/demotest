﻿using BoDi;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using TechTalk.SpecFlow;

namespace SpecFlowWithSelenium.Specs.Hooks
{
    [Binding]
    public sealed class WebDriverHooks
    {
        private readonly IObjectContainer container;

        public WebDriverHooks(IObjectContainer container)
        {
            this.container = container;
        }

        [BeforeScenario]
        public void BeforeScenario()
        {
            // logic that has to run before executing each scenario

            FirefoxOptions firefoxProfile = new FirefoxOptions();
            firefoxProfile.AcceptInsecureCertificates = true;
            var driver = new FirefoxDriver(Directory.GetParent(AppDomain.CurrentDomain.BaseDirectory).Parent.Parent.FullName, firefoxProfile);
            driver.Manage().Window.Maximize();

            container.RegisterInstanceAs<IWebDriver>(driver);
        }

        [AfterScenario]
        public void AfterScenario()
        {
            // logic that has to run after executing each scenario
            var driver = container.Resolve<IWebDriver>();

            if (driver != null)
            {
                driver.Quit();
                driver.Dispose();
            }
        }
    }
}
