﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace SpecFlowWithSelenium.Pages
{
    public class HomePageAutomationPracticePage : BasePage
    {
        public HomePageAutomationPracticePage(IWebDriver driver) : base(driver) { }

        private readonly By signInLink = By.LinkText("Sign in");
        private readonly By registerEmail = By.Id("email_create");
        private readonly By createRegisterButton = By.Id("SubmitCreate");
        private readonly By titleGenderMale = By.Id("id_gender1");
        private readonly By titleGenderFeMale = By.Id("id_gender2");
        private readonly By txtFirstName = By.Id("customer_firstname");
        private readonly By txtLastName = By.Id("customer_lastname");
        private readonly By txtPassword = By.Id("passwd");
        private readonly By selectDay = By.Id("days");
        private readonly By selectMonth = By.Id("months");
        private readonly By selectYear = By.Id("years");
        private readonly By addrTxtFirstName = By.Id("firstname");
        private readonly By addrTxtLastName = By.Id("lastname");
        private readonly By txtAddress1 = By.Id("address1");
        private readonly By txtCity = By.Id("city");
        private readonly By selectState = By.Id("id_state");
        private readonly By txtPostcode = By.Id("postcode");
        private readonly By selectCountry = By.Id("id_country");
        private readonly By txtMobilePhone = By.Id("phone_mobile");
        private readonly By btnSubmitRegistration = By.Id("submitAccount");

        public void SignInClick()
        {
            WaitForElementToBeVisible(signInLink);
            Click(signInLink);
        }

        public void EnterEmailId(string emailID)
        {
            WaitForElementToBeVisible(registerEmail);
            SendKeys(registerEmail, emailID);
        }

        public void OpenRegisterForm()
        {
            Click(createRegisterButton);
        }

        public void EnterRegistrationDetails(string title, string firstName, string lastName, string password, string dob, string address, string city, string state, string country, string postalcode, string mobilephone)
        {
            WaitForElementToBeVisible(titleGenderMale);
            if (title == "Mr")
            {
                var genderMale = GetRadioButtons(titleGenderMale).FirstOrDefault();
                genderMale.Click();
            }
            else
            {
                Click(titleGenderFeMale);
                var genderFeMale = GetRadioButtons(titleGenderFeMale).FirstOrDefault();
                genderFeMale.Click();
            }

            SendKeys(txtFirstName, firstName);
            SendKeys(txtLastName, lastName);
            SendKeys(txtPassword, password);

            // Parse day, month, year from DOB
            DateTime dateTime;
            try
            {
                dateTime = DateTime.ParseExact(dob, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            SelectElement day = GetSelectElement(selectDay);
            day.SelectByValue(dateTime.Day.ToString());

            SelectElement month = GetSelectElement(selectMonth);
            month.SelectByValue(dateTime.Month.ToString());

            SelectElement year = GetSelectElement(selectYear);
            year.SelectByValue(dateTime.Year.ToString());

            //SendKeys(addrTxtFirstName, firstName);
            //SendKeys(addrTxtLastName, lastName);
            SendKeys(txtAddress1, address);
            SendKeys(txtCity, city);

            SelectElement stateSelect = GetSelectElement(selectState);
            stateSelect.SelectByText(state);

            SendKeys(txtPostcode, postalcode);

            SelectElement countrySelect = GetSelectElement(selectCountry);
            countrySelect.SelectByText(country);

            SendKeys(txtMobilePhone, mobilephone);
        }
        public void SubmitRegistration()
        {
            Click(btnSubmitRegistration);
        }
    }
}
