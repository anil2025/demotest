﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace SpecFlowWithSelenium.Pages
{
    public class HomePage : BasePage
    {
        public HomePage(IWebDriver driver) : base(driver) { }

        private readonly By originClick = By.Id("source");
        private readonly By searchInput = By.Id("basic-url");
        private readonly By searchResult = By.Id("list-item");
        private readonly By destinationInput = By.CssSelector(".source-align-to input");
        private readonly By datePicker = By.ClassName("date-picker-input");
        private readonly By searchFlights = By.CssSelector("button.btn-flight");
        private readonly By LoginLink = By.CssSelector("[href='/partner-login']");


        public void EnterSource(string origin)
        {
            ScrollToThenClick(originClick);
            SendKeys(searchInput, origin);
            Click(searchResult);
        }

        public void EnterDestination(string destination)
        {
            SendKeys(destinationInput, destination);
            Click(searchResult);
        }

        public void SelectDepartDate(string departDate)
        {
            DateTime dateTime;
            try
            {
                dateTime = DateTime.ParseExact(departDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch(Exception ex) 
            {
                throw new Exception(ex.Message);
            }
                
            int month = dateTime.Month;
            int day = dateTime.Day;

            By dateSelect = By.CssSelector(".date-picker div[data-month-index='"+ month + "'] div[data-day-index='" + day + "']");

            Click(datePicker);
            Click(dateSelect);
            
        }
        public void SearchFlights()
        {
            Click(searchFlights);
        }
        public void LoginClick()
        {
            Click(LoginLink);
        }
    }
}
