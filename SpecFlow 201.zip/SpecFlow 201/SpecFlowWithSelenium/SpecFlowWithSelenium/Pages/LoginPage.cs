﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SpecFlowWithSelenium.Pages
{
    public class LoginPage : BasePage
    {
        public LoginPage(IWebDriver driver) : base(driver) { }

        private readonly By userNameInput = By.Id("username");
        private readonly By passwordInput = By.Id("text");
        private readonly By signInButton = By.CssSelector("button.btn-sm");
        private readonly By errorMessage = By.CssSelector("div[role = 'alert']");

        public void EnterUserName(string userName)
        {
            WaitForElementToBeVisible(userNameInput);
            SendKeys(userNameInput, userName);
        }
        public void EnterPassword(string password)
        {
            WaitForElementToBeVisible(passwordInput);
            SendKeys(passwordInput, password);
        }

        public void ClickSignIn()
        {
            Click(signInButton);
        }
        public string GetErrorMessage()
        {
            string error = GetListOfElementTexts(errorMessage).FirstOrDefault();
            return error;
        }
    }
}
