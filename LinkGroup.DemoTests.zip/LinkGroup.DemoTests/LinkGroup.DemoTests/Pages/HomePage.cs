﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace LinkGroup.DemoTests.Pages
{
    public class HomePage : Utils
    {
        public HomePage(IWebDriver driver) : base(driver) { }

        private readonly By acceptCookie = By.XPath("//div[contains(@class, 'cc-compliance')]//a[text()='Agree']");
        private readonly By selectSearch = By.Id("TN-search");
        private readonly By searchBox = By.CssSelector("input[name='searchTerm']");
        public readonly string searchTerm = "Leeds";
        private readonly By submitSearch = By.XPath("//li/div/form/button");

        public string GoTo(string url)
        {
            NavigateToURL(url);
            return GetPageTitle();
        }

        public void AcceptCookiePolicy()
        {
            WaitForElementToBeVisible(acceptCookie);
            Click(acceptCookie);
        }

        public void Search()
        {
            ScrollToThenClick(selectSearch);
            SendKeys(searchBox,searchTerm);
            Click(submitSearch);
        }
    }
}
