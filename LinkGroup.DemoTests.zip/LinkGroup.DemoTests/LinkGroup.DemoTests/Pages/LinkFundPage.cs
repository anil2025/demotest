﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace LinkGroup.DemoTests.Pages
{
    public class LinkFundPage : Utils
    {
        public LinkFundPage(IWebDriver driver) : base(driver) { }

        private readonly By fundMenu = By.Id("navItem-funds");
        private readonly By ukJurisdiction = By.XPath("//ul[contains(@class, 'nav flex-column')]/li[position()=1]");
        private readonly By swissJurisdiction = By.XPath("//ul[contains(@class, 'nav flex-column')]/li[position()=3]");
        public readonly string ukCountry = "UK";
        public readonly string Swiss = "Swiss";

        public void GoTo(string url)
        {
            NavigateToURL(url);
        }
        public void SelectJurisdiction(string country)
        {
            ScrollToThenClick(fundMenu);
            if (country == ukCountry)
                Click(ukJurisdiction);
            else if (country == Swiss)
                Click(swissJurisdiction);
        }
    }
}
