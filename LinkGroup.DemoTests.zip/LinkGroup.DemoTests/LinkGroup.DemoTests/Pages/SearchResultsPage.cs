﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace LinkGroup.DemoTests.Pages
{
    public class SearchResultsPage : Utils
    {
        public SearchResultsPage(IWebDriver driver) : base(driver) { }

        private readonly By searchResult = By.CssSelector("#SearchResults h3");

        public string GetResult()
        {
            string searchResultContent = GetElement(searchResult).Text;
            searchResultContent = Regex.Replace(searchResultContent, @"\s+", " ").Replace("\"", string.Empty);
            return searchResultContent;
        }
    }
}
