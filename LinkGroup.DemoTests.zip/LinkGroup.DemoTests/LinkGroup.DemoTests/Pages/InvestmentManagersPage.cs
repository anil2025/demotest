﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace LinkGroup.DemoTests.Pages
{
    public class InvestmentManagersPage : Utils
    {
        public InvestmentManagersPage(IWebDriver driver) : base(driver) { }
        public readonly string UKInvestManagers = "Investment Managers for UK investors";
        public readonly string SwissInvestManagers = "Investment Managers for Swiss investors";
        private readonly By breadCrumbNavigation = By.XPath("//div[contains(@id, 'breadcrumb')]//li[position()=2]");

        public string GetBreadCrumbTitle()
        {
            return GetElement(breadCrumbNavigation).Text;
        }
    }
}
