﻿using FluentAssertions;
using LinkGroup.DemoTests;
using LinkGroup.DemoTests.Pages;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using TechTalk.SpecFlow;

namespace LinkGroup.DemoTest.Specs.Steps
{
    [Binding]
    public class SearchResultsSteps : Utils
    {
        private readonly ScenarioContext _scenarioContext;
        private readonly SearchResultsPage searchResultsPage;
        private readonly HomePage homePage;
        private readonly string siteUrl = "https://www.linkgroup.eu/";

        public SearchResultsSteps(IWebDriver driver, ScenarioContext scenarioContext) : base(driver)
        {
            _scenarioContext = scenarioContext;
            searchResultsPage = new SearchResultsPage(driver);
            homePage = new HomePage(driver);
            //Driver = driver; 
        }

        [Given(@"I have opened the home page")]
        public void GivenIHaveOpenedTheHomePage()
        {
            Driver.Navigate().GoToUrl(siteUrl);
        }
        
        [Given(@"I have agreed to the cookie policy")]
        public void GivenIHaveAgreedToTheCookiePolicy()
        {
            homePage.AcceptCookiePolicy();
        }
        
        [When(@"I search for '(.*)'")]
        public void WhenISearchFor(string p0)
        {
            homePage.Search();
        }
        
        [Then(@"the search results are displayed")]
        public void ThenTheSearchResultsAreDisplayed()
        {
            string expectedSearchResult = "You searched for: Leeds";
            
            string searchResultList = searchResultsPage.GetResult();

            //searchResultList.Should().Equals(expectedSearchResult);
            Assert.IsTrue(searchResultList.Contains(expectedSearchResult));
        }
    }
}
