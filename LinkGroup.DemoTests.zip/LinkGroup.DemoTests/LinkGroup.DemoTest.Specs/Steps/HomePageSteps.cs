﻿using LinkGroup.DemoTests;
using LinkGroup.DemoTests.Pages;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Configuration;
using TechTalk.SpecFlow;

namespace LinkGroup.DemoTest.Specs.Steps
{
    [Binding]
    public class HomepageSteps : Utils
    {
        private readonly ScenarioContext _scenarioContext;
        private HomePage homePage;
        private readonly string homePageUrl = "https://www.linkgroup.eu/";
        private readonly IWebDriver _driver;

        public HomepageSteps(IWebDriver driver, ScenarioContext scenarioContext) : base(driver)
        {
            _scenarioContext = scenarioContext;
            homePage = new HomePage(driver);
        }

        [When(@"I open the home page url")]
        public void WhenIOpenTheHomePageUrl()
        {
            homePage.GoTo(homePageUrl);
        }

        [Then(@"home page is displayed")]
        public void ThenHomePageIsDisplayed()
        {
            Assert.IsTrue(GetPageTitle().Contains("Home"));
        }
    }
}
