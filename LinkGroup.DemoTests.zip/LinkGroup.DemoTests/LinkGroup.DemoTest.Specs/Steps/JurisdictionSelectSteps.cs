﻿using LinkGroup.DemoTests;
using LinkGroup.DemoTests.Pages;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using TechTalk.SpecFlow;

namespace LinkGroup.DemoTest.Specs.Steps
{
    [Binding]
    public class JurisdictionSelectSteps : Utils
    {
        private readonly ScenarioContext _scenarioContext;
        private LinkFundPage linkFundPage;
        private readonly string linkFundPageUrl = "https://www.linkfundsolutions.co.uk/";

        public JurisdictionSelectSteps(IWebDriver driver, ScenarioContext scenarioContext) : base(driver)
        {
            _scenarioContext = scenarioContext;
            linkFundPage = new LinkFundPage(driver);
        }

        [When(@"I open the Found Solutions page")]
        public void WhenIOpenTheFoundSolutionsPage()
        {
            linkFundPage.GoTo(linkFundPageUrl);
        }

        [Then(@"Then I can select the (.*) jurisdiction")]
        public void ThenThenICanSelectTheJurisdiction(string p0)
        {
            linkFundPage.SelectJurisdiction(linkFundPage.ukCountry);

            InvestmentManagersPage investmentManagersPage = new InvestmentManagersPage(Driver);
            Assert.IsTrue(investmentManagersPage.GetBreadCrumbTitle().Contains(investmentManagersPage.UKInvestManagers));
        }
    }
}
