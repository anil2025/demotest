
Name: Anilkumar
Date of completion: 24-June-2021
Code developed using Visual studio 2019.

System limitation: 
Latest chrome driver unavailability and require ticket approval for downloading .exe in laptop and mismatched with latest chrome driver Nuget package, hence, Firefox driver is utilized.

Assumptions:
#2 Feature: Link Fund Solutions (Optional) - Website link https://www.linkfundsolutions.co.uk/ does not contain any element on page for Jurisdiction. Hence, it is assumed that website design might have changed and for completing assignment we are navigation below paths
1. Funds -> Investment Managers for UK investors and Asserting that correct page is loaded by verifying that breadcumb Menu contains "Investment Managers for Swiss investors"
OR
2. Funds -> Investment Managers for Swiss investors and Asserting that correct page is loaded by verifying that breadcumb Menu contains "Investment Managers for Swiss investors"

Project Structure:
LinkGroup.DemoTest.SpecsLinkGroup.DemoTest.Specs => Contains Specflow features and step definitions
LinkGroup.DemoTests => Page object models, common utility class for handling browser interactions


